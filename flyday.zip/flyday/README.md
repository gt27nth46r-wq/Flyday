# Flyday

A 7-day go/no-go outlook for single-engine VFR flying.

**Core rating rule (as specified):**
- **Good** — the area is under a high pressure system (avg forecast pressure ≥ threshold, default **1020 hPa**) *and* forecast wind is under your threshold (default **10 kt**)
- **Marginal** — only one of those two holds
- **Bad** — neither holds
- **Unknown** — the model doesn't reach that far out yet (rare, usually day 7)

**Safety gate on top of that:** ceiling and visibility can only pull a rating down, never up. A day can't be called Good below your ceiling/visibility thresholds (default 3,000 ft / 5 sm), and drops straight to Bad below basic VFR minimums (1,000 ft / 3 sm) no matter what the pressure and wind look like.

All four thresholds are editable in the "Thresholds & runway" panel in the UI.

**Also shown per day:**
- **Density altitude** (worst case, using the day's forecast high temperature) — computed from your airport's field elevation, so you can see when a day that looks calm on paper is still a short-field/high-DA problem.
- **Crosswind component** for a runway heading you enter (e.g. `13/31`) — computed live in your browser from the hourly forecast wind, never sent to the server. Forecast wind direction is true north and runway numbers are magnetic, so treat it as an estimate, not gospel.
- An **hourly breakdown** (wind, ceiling, visibility, temp, precip chance) you can expand on any day card.

**Other additions:**
- **Favorites** — save airports you check often; they show up as chips under the search box (stored in your browser only).
- **Route comparison** — expand "Compare a route", enter a comma-separated list of airports, and see a Good/Marginal/Bad matrix across all of them for the week.

## Why a backend at all

aviationweather.gov's API explicitly does **not** send CORS headers, so a browser can't call it directly — the request just gets blocked. This app is a small Node/Express server that does the calling server-side (where CORS doesn't apply) and hands your browser clean JSON. It also means your contact info (see below) only has to live in one place.

## Where the data comes from

| Data | Source | Why |
|---|---|---|
| Airport → lat/lon | `aviationweather.gov/api/data/stationinfo` | You asked for aviationweather.gov as the backbone |
| Current conditions + flight category | `aviationweather.gov/api/data/metar` | Ground truth for "right now" |
| Near-term (~24–30h) forecast + flight category | `aviationweather.gov/api/data/taf` | Best near-term source, shown as a badge on day 1–2 |
| 7-day pressure, wind, ceiling, visibility, temperature | `api.weather.gov` gridpoint forecast | **aviationweather.gov's TAFs only run ~24–30 hours out — there's no 7-day product there.** The NWS gridpoint forecast is the standard free source for a multi-day numerical outlook, and it's what Flyday uses for the whole week: pressure/wind for the core rule, ceiling/visibility for the safety gate, and temperature (with your airport's elevation) for density altitude. |

One honest caveat: the NWS gridpoint `pressure` value is station-level barometric pressure from the forecast model, not a hand-analyzed sea-level pressure chart — it's a solid proxy for "is this a high-pressure, stable-air day" but isn't the same thing a briefer means by "the center of a 1030 mb high is over the area." Good enough for planning; not a substitute for looking at an actual surface analysis chart before you fly.

## Run it locally

```bash
cd server
cp .env.example .env   # then edit .env — see below
npm install
npm start
```

Open `http://localhost:3000`.

### You must edit `.env`

Both weather APIs ask every client to identify itself:

```
APP_USER_AGENT="Flyday (you@example.com)"
```

Put a real app name and an email you check. This isn't optional — it's how NOAA/NWS reach you if your app starts misbehaving, and it's good citizenship on a free public service.

## Deploying it for real

The whole app (API + static frontend) is one Node process, so it deploys anywhere that runs Node 18+:

- **Render / Railway / Fly.io**: point them at the `server/` folder, build command `npm install`, start command `npm start`, set `APP_USER_AGENT` (and optionally the threshold/cache env vars) in their dashboard.
- **A VPS**: `npm install && npm start` behind `pm2` or a systemd unit, reverse-proxied by Caddy/nginx for TLS.

There's nothing to build for the frontend — `public/` is plain HTML/CSS/JS served by Express, no bundler needed.

## Project layout

```
server/
  server.js          Express app + /api/forecast route
  lib/geo.js          ICAO -> lat/lon -> NWS gridpoint resolution (+ field elevation)
  lib/nwsGrid.js       Builds an hourly timeline, then daily summaries (pressure, wind, ceiling, visibility, temp)
  lib/aviationWeather.js  METAR/TAF fetch + parsing (current flight category, ceiling from cloud layers)
  lib/rating.js        The Good/Marginal/Bad rule, plus the crosswind-component formula
  lib/density.js       Density altitude formula
  .env.example
public/
  index.html, style.css, app.js   Frontend, no build step — favorites, runway/crosswind,
                                   hourly drill-down, and route comparison all live in app.js
```

## Extending it further

- The go/no-go rule lives in `lib/rating.js` — `rateDay()` for the thresholds, `crosswindComponentKt()` for the runway math. The daily summary object already carries everything the rule doesn't currently use (`avgSkyCoverPct`, `avgWindKt`) if you want to fold those in too.
- Crosswind is computed **client-side** in `app.js` (`maxCrosswindForDay`) from the hourly array the API already returns — that's deliberate, so changing your runway doesn't need a new server round-trip. If you'd rather have the server pick the *best* runway automatically, you'd need real per-airport runway data (aviationweather.gov's station info doesn't include it) — something like the FAA's NASR data or a service like AviationAPI would be the next piece to add in `lib/geo.js`.
- Route comparison currently just fetches each airport independently and lines up the ratings side by side — it doesn't yet interpolate weather *between* airports along the actual course line. That'd be the natural next step if you're routinely flying cross-country rather than checking a handful of familiar fields.
